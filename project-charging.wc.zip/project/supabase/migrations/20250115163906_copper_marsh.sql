/*
  # Create Charging Stations Schema

  1. New Tables
    - `charging_stations`
      - `id` (uuid, primary key)
      - `name` (text)
      - `latitude` (double precision)
      - `longitude` (double precision)
      - `address` (text)
      - `available` (integer)
      - `total` (integer)
      - `rating` (double precision)
      - `price_per_kwh` (double precision)
      - `connector_types` (text array)
      - `power_output` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `reviews`
      - `id` (uuid, primary key)
      - `station_id` (uuid, foreign key)
      - `user_id` (uuid, foreign key)
      - `rating` (integer)
      - `comment` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create charging stations table
CREATE TABLE charging_stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  address text NOT NULL,
  available integer NOT NULL DEFAULT 0,
  total integer NOT NULL DEFAULT 0,
  rating double precision NOT NULL DEFAULT 0,
  price_per_kwh double precision NOT NULL,
  connector_types text[] NOT NULL,
  power_output integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  station_id uuid REFERENCES charging_stations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE charging_stations ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Policies for charging stations
CREATE POLICY "Charging stations are viewable by everyone"
  ON charging_stations
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only authenticated users can insert charging stations"
  ON charging_stations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policies for reviews
CREATE POLICY "Reviews are viewable by everyone"
  ON reviews
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create reviews"
  ON reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reviews"
  ON reviews
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Function to update station rating
CREATE OR REPLACE FUNCTION update_station_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE charging_stations
  SET rating = (
    SELECT AVG(rating)::numeric(3,1)
    FROM reviews
    WHERE station_id = NEW.station_id
  )
  WHERE id = NEW.station_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update station rating when reviews change
CREATE TRIGGER update_station_rating_trigger
AFTER INSERT OR UPDATE OR DELETE ON reviews
FOR EACH ROW
EXECUTE FUNCTION update_station_rating();
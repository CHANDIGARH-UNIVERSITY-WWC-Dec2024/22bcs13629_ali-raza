import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import MapView from './components/Map';
import StationList from './components/StationList';
import SearchFilters from './components/SearchFilters';
import { ChargingStation } from './types';
import { EvStation } from 'lucide-react';

// Initialize Supabase client
const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

function App() {
  const [stations, setStations] = useState<ChargingStation[]>([]);
  const [selectedStation, setSelectedStation] = useState<ChargingStation | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStations();
  }, []);

  const fetchStations = async () => {
    try {
      const { data, error } = await supabase
        .from('charging_stations')
        .select('*');
      
      if (error) throw error;
      
      setStations(data || []);
    } catch (error) {
      console.error('Error fetching stations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (query: string) => {
    // Implement search logic
  };

  const handleFilterChange = (filters: any) => {
    // Implement filter logic
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <EvStation className="w-12 h-12 text-blue-500 mx-auto animate-pulse" />
          <p className="mt-4 text-gray-600">Loading charging stations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center space-x-2">
            <EvStation className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-gray-900">EV Charging Stations</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
          <div className="lg:col-span-1 bg-white rounded-lg shadow-sm overflow-hidden">
            <SearchFilters
              onSearch={handleSearch}
              onFilterChange={handleFilterChange}
            />
            <StationList
              stations={stations}
              selectedStation={selectedStation}
              onStationSelect={setSelectedStation}
            />
          </div>
          
          <div className="lg:col-span-2 bg-white rounded-lg shadow-sm overflow-hidden">
            <MapView
              stations={stations}
              selectedStation={selectedStation}
              onStationSelect={setSelectedStation}
            />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
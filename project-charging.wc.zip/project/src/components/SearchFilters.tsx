import React from 'react';
import { Search, Filter } from 'lucide-react';

interface SearchFiltersProps {
  onSearch: (query: string) => void;
  onFilterChange: (filters: any) => void;
}

export default function SearchFilters({ onSearch, onFilterChange }: SearchFiltersProps) {
  return (
    <div className="p-4 border-b">
      <div className="relative">
        <input
          type="text"
          placeholder="Search for charging stations..."
          className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          onChange={(e) => onSearch(e.target.value)}
        />
        <Search className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
      </div>
      
      <div className="mt-4 flex flex-wrap gap-2">
        <select
          className="px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          onChange={(e) => onFilterChange({ connector: e.target.value })}
        >
          <option value="">All Connectors</option>
          <option value="CCS">CCS</option>
          <option value="CHAdeMO">CHAdeMO</option>
          <option value="Type2">Type 2</option>
        </select>
        
        <select
          className="px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          onChange={(e) => onFilterChange({ availability: e.target.value })}
        >
          <option value="">All Stations</option>
          <option value="available">Available Now</option>
        </select>
        
        <select
          className="px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          onChange={(e) => onFilterChange({ power: e.target.value })}
        >
          <option value="">All Power Levels</option>
          <option value="50">50kW+</option>
          <option value="150">150kW+</option>
          <option value="350">350kW+</option>
        </select>
      </div>
    </div>
  );
}
import React from 'react';
import Map, { Marker, Popup } from 'react-map-gl';
import { ChargingStation } from '../types';
import { EvStation } from 'lucide-react';

interface MapViewProps {
  stations: ChargingStation[];
  selectedStation: ChargingStation | null;
  onStationSelect: (station: ChargingStation) => void;
}

const MAPBOX_TOKEN = 'pk.eyJ1IjoiZXhhbXBsZSIsImEiOiJjbGVhcm5vdGFyZWFsdG9rZW4ifQ.dGhpc2lzYWZha2V0b2tlbg';

export default function MapView({ stations, selectedStation, onStationSelect }: MapViewProps) {
  return (
    <Map
      initialViewState={{
        latitude: 40.7128,
        longitude: -74.0060,
        zoom: 12
      }}
      style={{ width: '100%', height: '100%' }}
      mapStyle="mapbox://styles/mapbox/streets-v12"
      mapboxAccessToken={MAPBOX_TOKEN}
    >
      {stations.map((station) => (
        <Marker
          key={station.id}
          latitude={station.latitude}
          longitude={station.longitude}
          onClick={(e) => {
            e.originalEvent.stopPropagation();
            onStationSelect(station);
          }}
        >
          <div className="cursor-pointer">
            <EvStation
              className={`w-8 h-8 ${
                station.available > 0 ? 'text-green-500' : 'text-red-500'
              }`}
            />
          </div>
        </Marker>
      ))}

      {selectedStation && (
        <Popup
          latitude={selectedStation.latitude}
          longitude={selectedStation.longitude}
          closeButton={true}
          closeOnClick={false}
          onClose={() => onStationSelect(null)}
          anchor="bottom"
        >
          <div className="p-2">
            <h3 className="font-bold text-lg">{selectedStation.name}</h3>
            <p className="text-sm text-gray-600">{selectedStation.address}</p>
            <div className="mt-2">
              <p className="text-sm">
                Available: {selectedStation.available}/{selectedStation.total} stations
              </p>
              <p className="text-sm">${selectedStation.price_per_kwh}/kWh</p>
              <p className="text-sm">{selectedStation.power_output}kW Output</p>
            </div>
          </div>
        </Popup>
      )}
    </Map>
  );
}
import React from 'react';
import { ChargingStation } from '../types';
import { Star, Battery, Zap } from 'lucide-react';

interface StationListProps {
  stations: ChargingStation[];
  onStationSelect: (station: ChargingStation) => void;
  selectedStation: ChargingStation | null;
}

export default function StationList({ stations, onStationSelect, selectedStation }: StationListProps) {
  return (
    <div className="overflow-y-auto h-full">
      {stations.map((station) => (
        <div
          key={station.id}
          className={`p-4 border-b cursor-pointer hover:bg-gray-50 ${
            selectedStation?.id === station.id ? 'bg-blue-50' : ''
          }`}
          onClick={() => onStationSelect(station)}
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-lg">{station.name}</h3>
              <p className="text-sm text-gray-600">{station.address}</p>
            </div>
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400" />
              <span className="ml-1 text-sm">{station.rating.toFixed(1)}</span>
            </div>
          </div>
          
          <div className="mt-2 flex items-center space-x-4">
            <div className="flex items-center">
              <Battery className="w-4 h-4 text-gray-600 mr-1" />
              <span className="text-sm">
                {station.available}/{station.total} available
              </span>
            </div>
            <div className="flex items-center">
              <Zap className="w-4 h-4 text-gray-600 mr-1" />
              <span className="text-sm">${station.price_per_kwh}/kWh</span>
            </div>
          </div>
          
          <div className="mt-2">
            <div className="flex flex-wrap gap-2">
              {station.connector_types.map((type) => (
                <span
                  key={type}
                  className="px-2 py-1 text-xs bg-gray-100 rounded-full"
                >
                  {type}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
export interface ChargingStation {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  address: string;
  available: number;
  total: number;
  rating: number;
  price_per_kwh: number;
  connector_types: string[];
  power_output: number;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: string;
  station_id: string;
  user_id: string;
  rating: number;
  comment: string;
  created_at: string;
}